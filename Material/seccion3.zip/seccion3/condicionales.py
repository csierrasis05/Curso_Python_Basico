# SI pasa algo {codigo} NO  pasa { hay otros codigo respuesta }

edad = 22
if edad <18:
    print(" es menor")

elif edad < 22:
    print("puede viajar")
elif edad < 23:
    print("puede votar")
else:
    print("es mayor")


