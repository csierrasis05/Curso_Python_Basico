#bloque pequeño de texto que queremos mostar por pantalla
#f formatear datos 
 
edad=24
cadena=f"hola chicos tengo {edad} años"
ciudad = "\t huanuco peru"
print(cadena+ciudad)


