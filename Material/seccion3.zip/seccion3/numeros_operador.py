
#Definicion de numeros
#Operadores

print(6+6)
print(6-6)
print(6*6)
print(6/6)
print(6%6)
print(6**3)


