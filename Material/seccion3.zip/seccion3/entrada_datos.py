#ENTRADA POR TECLADO
"""nombre=input("ingrese nombre:")
edad=int(input("ingrese edad:"))
talla=float(input("ingrse estatura:"))
print(f" el nombre es: {nombre}")
print(f" edad es: {edad}")
print(f" estatura es: {talla}")"""

#entrada por teclado en una lista
print("------RELLENAR LOS 3 DATOS--------")
lista=[]
for i in range(3):
    i=i+1
    entrada=input(f"ingrse dato {i}:")
    lista.append(entrada)
print(lista)




    
