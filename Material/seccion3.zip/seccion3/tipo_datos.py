# Definicion de variable: donde almacenamos informacion


dato = 34
dato_texto = "dsdsadsa"

# Tipos de datos numericos Enteros(int) y los reales(float)

numero = 23
numero_real = 34.9
print(numero, numero_real)

#Tipo de dato TEXTO
texto = "Hola"
print(texto)

# tIPO de dato Boleean
Bolean = True
print(Bolean)

