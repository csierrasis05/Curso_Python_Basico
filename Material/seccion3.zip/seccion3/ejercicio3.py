#EJERCICIO3: Aplicaciones propias con varios modulos:

import operaciones

lista=operaciones.listar()
operaciones.listar_mayor(lista)
operaciones.listar_suma(lista)

